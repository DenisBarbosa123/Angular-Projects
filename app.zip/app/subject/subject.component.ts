import { Component, OnInit } from '@angular/core';
import { SubjectService } from '../subject.service';
import { Subject } from '../subject';

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.css']
})
export class SubjectComponent {

  constructor(private subjectService : SubjectService) { }
  subjects : Subject[];
  subject : Subject;
  ngOnInit() {
    this.subjects = [];
    this.subject = new Subject();
    this.getAll();
  }

  getAll() {
    this.subjectService.getAll().subscribe(
      data => this.subjects = data
    );
  }


}
